<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Medical Form</title>
    <link href="styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-7">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3>
                                </div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="inputFirstName" type="text"
                                                        placeholder="Enter your first name" />
                                                    <label for="inputFirstName">First name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating">
                                                    <input class="form-control" id="inputLastName" type="text"
                                                        placeholder="Enter your last name" />
                                                    <label for="inputLastName">Last name</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="umur" type="text"
                                                        placeholder="What is your age?" />
                                                    <label for="umur">What is your age?</label>
                                                </div>
                                            </div>
                                            <!-- gender (radio) -->
                                            <div class="col-md-6">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="gender" id="cowo"
                                                        value="cowo">
                                                    <label class="form-check-label" for="cowo">Laki-Laki</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="gender" id="cewe"
                                                        value="cewe">
                                                    <label class="form-check-label" for="cewe">Perempuan</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="email" type="email"
                                                placeholder="name@example.com" />
                                            <label for="email">Email address</label>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <select class="form-control form-control-sm">
                                                    <option selected>Agama</option>
                                                    <option value="islam">Islam</option>
                                                    <option value="kristen">Kristen</option>
                                                    <option value="katolik">Katolik</option>
                                                    <option value="hindu">Hindu</option>
                                                    <option value="budha">Budha</option>
                                                    <option value="konghucu">Konghucu</option>
                                                </select>
                                            </div>
                                            <div class="col-md-6">
                                                <select class="form-control form-control-sm">
                                                    <option selected>Jenjang Pendidikan</option>
                                                    <option value="tk">TK</option>
                                                    <option value="sd">SD</option>
                                                    <option value="smp">SMP</option>
                                                    <option value="sma">SMA</option>
                                                    <option value="d1">D1</option>
                                                    <option value="d2">D2</option>
                                                    <option value="d3">D3</option>
                                                    <option value="s1">S1</option>
                                                    <option value="s2">S2</option>
                                                    <option value="s3">S3</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="kota" type="text"
                                                        placeholder="Nama Kota" />
                                                    <label for="kota">Nama Kota</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-floating mb-3 mb-md-0">
                                                    <input class="form-control" id="provinsi" type="text"
                                                        placeholder="Provinsi" />
                                                    <label for="provinsi">Provinsi</label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="card-header mb-4">
                                            <h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3>
                                        </div>

                                        <div class="p-2">
                                            <div class="form-group mb-4">
                                                <p>Periksa ketentuan yang berlaku untuk Anda atau anggota kerabat dekat
                                                    anda:</p>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="asma"
                                                        value="asma">
                                                    <label class="form-check-label" for="asma">Asma</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="jantung"
                                                        value="jantung">
                                                    <label class="form-check-label" for="jantung">Penyakit
                                                        Jantung</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="kanker"
                                                        value="kanker">
                                                    <label class="form-check-label" for="kanker">Kanker</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="diabet"
                                                        value="diabet">
                                                    <label class="form-check-label" for="diabet">Diabetes</label>
                                                </div>
                                            </div>

                                            <div class="form-group mb-4">
                                                <p>Periksa gejala yang Anda alamai saat ini:</p>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="dada"
                                                        value="dada">
                                                    <label class="form-check-label" for="dada">Sakit Dada</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="kardiovaskular"
                                                        value="kardiovaskular">
                                                    <label class="form-check-label"
                                                        for="kardiovaskular">kardiovaskular</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="pernafasan"
                                                        value="pernafasan">
                                                    <label class="form-check-label" for="pernafasan">Pernafasan</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" id="penbb"
                                                        value="penbb">
                                                    <label class="form-check-label" for="penbb">Penambahan BB</label>
                                                </div>
                                            </div>
                                            <div class="form-group mb-4">
                                                <p>Silahkan list yang lain:</p>
                                                <textarea class="form-control" id="lainnya"></textarea>
                                            </div>
                                        </div>

                                        <div>
                                            <div class="d-grid"><a class="btn btn-primary btn-block"
                                                    href="/output">Submit</a></div>
                                        </div>

                                    </form>
                                </div>
                                <div class="card-footer text-center py-3">
                                    <h3>Take care of your health</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Your Website 2022</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous"></script>
    <script src="scripts.js"></script>
</body>

</html>